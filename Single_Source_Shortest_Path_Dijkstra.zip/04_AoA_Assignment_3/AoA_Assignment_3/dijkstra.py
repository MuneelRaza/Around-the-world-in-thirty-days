# graph = {"a": [("b", 2), ("f", 3), ("k", 9)], "b": [("c", 2), ("d", 3), ("a", 2)],
#          "c": [("b", 2), ("e", 1), ("k", 3)], "d": [("b", 3), ("e", 1), ("f", 2)],
#          "e": [("c", 1), ("d", 1)], "f": [("a", 3), ("d", 2), ("g", 3)],
#          "g": [("f", 3), ("h", 2)], "h": [("g", 2), ("i", 6), ("j", 4)],
#          "i": [("j", 3), ("h", 6), ("k", 3)], "j": [("i", 3), ("h", 4)],
#          "k": [("a", 9), ("i", 3), ("c", 3)]}

from adjacency_list import graph


def dijkstra(graph, vertex):
    B = {}
    Q = []
    B[vertex] = 0
    Q.extend(graph[vertex])
    Q = [v for v in Q if v[0] != vertex]
    path = {}
    while len(Q) != 0:
        distance_list = []
        parent = {}
        for u in B:
            for v in graph[u]:
                if v[0] not in B.keys():
                    distance_list.append((v[0], v[1] + B[u]))
                if v[0] not in parent.keys():
                    parent[v[0]] = []
                    parent[v[0]].append(u)
                else:
                    parent[v[0]].append(u)

        distance_list.sort(key=lambda i: i[1], reverse=False)
        if len(distance_list) != 0:
            # updating the Q which does not contain the vertices which are in bucket
            Q = [v for v in Q if v[0] != distance_list[0][0]]
            B[distance_list[0][0]] = distance_list[0][1]
            if distance_list[0][0] not in path.keys():
                path[distance_list[0][0]] = []
                for parent in parent[distance_list[0][0]]:
                    for var in graph[parent]:
                        if var[0] == distance_list[0][0] and (var[1] + B[parent]) == distance_list[0][1]:
                            # path[distance_list[0][0]].append(path[distance_list[0]])
                            if parent in path.keys():
                                for p in path[parent]:
                                    path[distance_list[0][0]].append(p)
                            path[distance_list[0][0]].append(parent)
            else:
                for parent in parent[distance_list[0][0]]:
                    for var in graph[parent]:
                        if var[0] == distance_list[0][0] and (var[1] + B[parent]) == distance_list[0][1]:
                            path[distance_list[0][0]].append(parent)
            for u in graph[distance_list[0][0]]:
                if u[0] not in B.keys():
                    Q.append(u)
    return B, path


print(dijkstra(graph, "AZ"))


