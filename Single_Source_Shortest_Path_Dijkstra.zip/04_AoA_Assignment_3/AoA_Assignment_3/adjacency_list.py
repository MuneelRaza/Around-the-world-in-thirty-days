distances = open("distance_matrix.txt", "r")
distance_matrix = []
for row in distances:
    row = row.split(" ")
    temp = []
    for num in row:
        if num != "":
            temp.append(int(num))
    distance_matrix.append(temp)

# print(distance_matrix)
cities = open("cities.txt", "r")
city_codes = []
for city in cities:
    city_codes.append(city[0:2])

# print(city_codes)
graph = {}
for i in range(len(distance_matrix)):
    graph[city_codes[i]] = []
    row = distance_matrix[i]
    for j in range(30):
        graph[city_codes[i]].append((city_codes[j], row[j]))

# print(graph)
